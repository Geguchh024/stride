# SPDX-License-Identifier: GPL-3.0-or-later
"""Arm and hand proportions: the skeleton and the shapes that make the skin (numpy, no bpy).

Everything is for the right arm in the body frame (origin at the eyes, +X
right, +Y forward, +Z up, metres); the left arm is its mirror image. Hand
details are written in hand space: origin at the wrist, +Y towards the
fingers, +Z the back of the hand, +X the little-finger side.
"""

import math
from dataclasses import dataclass

import numpy as np

from . import sdf

FINGERS = ("index", "middle", "ring", "pinky")


def _n(v):
    v = np.asarray(v, float)
    return v / np.linalg.norm(v)


@dataclass
class Build:
    """Body variations: overall size and how thick the limbs are."""
    size: float = 1.0
    girth: float = 1.0
    finger_girth: float = 1.0


BUILDS = {
    "AVERAGE": Build(),
    "SLIM": Build(size=0.94, girth=0.88, finger_girth=0.9),
    "STRONG": Build(size=1.03, girth=1.15, finger_girth=1.08),
}

# finger: MCP joint (hand space), spread (degrees towards the thumb), phalanx lengths, radii at
# MCP / PIP / DIP / tip
FINGER_DATA = {
    "index": ((-0.0250, 0.0935, 0.0010), 5.0, (0.0410, 0.0245, 0.0195), (0.0098, 0.0091, 0.0084, 0.0078)),
    "middle": ((-0.0045, 0.0975, 0.0020), 0.0, (0.0455, 0.0285, 0.0205), (0.0101, 0.0094, 0.0087, 0.0080)),
    "ring": ((0.0150, 0.0930, 0.0005), -5.0, (0.0430, 0.0270, 0.0200), (0.0094, 0.0088, 0.0081, 0.0075)),
    "pinky": ((0.0325, 0.0815, -0.0025), -11.0, (0.0335, 0.0200, 0.0180), (0.0083, 0.0077, 0.0071, 0.0066)),
}
THUMB_CMC = (-0.0205, 0.0215, -0.0105)
THUMB_DIRS = ((-0.66, 0.68, -0.30), (-0.38, 0.90, -0.22), (-0.22, 0.96, -0.17))
THUMB_LENGTHS = (0.0455, 0.0330, 0.0280)
THUMB_RADII = (0.0128, 0.0118, 0.0108, 0.0098)
THUMB_NAIL = (-0.80, 0.05, 0.60)       # which way the thumbnail faces


class Arm:
    """Joint positions, bones and skin shapes of one arm in its rest pose."""

    def __init__(self, build=None, side=1):
        b = build or Build()
        self.side = side
        self.build = b
        s = b.size
        self.shoulder = np.array([0.170 * s, -0.070, -0.210 * s])
        self.clav_root = np.array([0.030, -0.075, -0.200])
        self.upper_len = 0.290 * s
        self.fore_len = 0.260 * s
        u = _n((0.05, 0.35, -1.0))
        f = _n((-0.08, 1.0, 0.05))
        self.elbow = self.shoulder + u * self.upper_len
        self.wrist = self.elbow + f * self.fore_len
        hz = _n(np.array([0, 0, 1.0]) - f * f[2])
        hx = np.cross(f, hz)
        self.hand_rot = np.column_stack([hx, f, hz])     # hand space -> body frame
        self.u_dir, self.f_dir, self.hand_z = u, f, hz
        self._fingers()

    # -- hand space helpers -----------------------------------------------------

    def hp(self, p):
        """Hand-space point to the body frame (hand dimensions scale with the build)."""
        return self.wrist + self.hand_rot @ (np.asarray(p, float) * self.build.size)

    def hd(self, d):
        return self.hand_rot @ _n(d)

    def _fingers(self):
        self.chains = {}
        for name, (mcp, spread, lengths, radii) in FINGER_DATA.items():
            a = math.radians(spread)
            d = self.hd((-math.sin(a), math.cos(a), -0.02))
            p0 = self.hp(mcp)
            joints = [p0]
            for ln in lengths:
                joints.append(joints[-1] + d * ln * self.build.size)
            self.chains[name] = (joints, [r * self.build.finger_girth * self.build.size for r in radii],
                                 d, self.hand_z)
        joints = [self.hp(THUMB_CMC)]
        for d, ln in zip(THUMB_DIRS, THUMB_LENGTHS):
            joints.append(joints[-1] + self.hd(d) * ln * self.build.size)
        self.chains["thumb"] = (joints, [r * self.build.finger_girth * self.build.size for r in THUMB_RADII],
                                self.hd(THUMB_DIRS[1]), self.hd(THUMB_NAIL))

    # -- skeleton ------------------------------------------------------------------

    def bones(self):
        """(name, head, tail, z axis reference, parent, connected) for the right arm."""
        out = [
            ("clavicle", self.clav_root, self.shoulder, (0, 0, 1), None, False),
            ("upper_arm", self.shoulder, self.elbow, -self.f_dir, "clavicle", True),
            ("forearm", self.elbow, self.wrist, self.hand_z, "upper_arm", True),
            ("forearm_twist", self.elbow, self.wrist, self.hand_z, "forearm", False),
            ("hand", self.wrist, self.hp((0, 0.085, 0)), self.hand_z, "forearm_twist", True),
        ]
        for name in ("thumb",) + FINGERS:
            joints, _r, _d, zref = self.chains[name]
            for k in range(3):
                parent = "hand" if k == 0 else f"{name}.{k:02d}"
                out.append((f"{name}.{k + 1:02d}", joints[k], joints[k + 1], zref, parent, k > 0))
        return out

    # -- skin shapes ---------------------------------------------------------------

    def skin(self):
        """Groups of shapes, blended within each group and with the palm."""
        g = self.build.girth
        fg = self.build.finger_girth * self.build.size
        S, E, W = self.shoulder, self.elbow, self.wrist
        hz = self.hand_z
        f = self.f_dir
        M = E + (W - E) * 0.45
        arm = [
            sdf.cone("upper_arm", S, E, 0.050 * g, 0.041 * g, z_ref=-f, sx=1.0, sz=0.95,
                     parent="clavicle", r0=0.05, child="forearm", r1=0.035),
            sdf.ellipsoid("upper_arm", S + (E - S) * 0.55 + _n(np.cross(self.u_dir, (1, 0, 0))) * -0.012,
                          np.array([0.038, 0.085, 0.036]) * g, y_axis=E - S, z_ref=-f,
                          axis=(S, E), parent="clavicle", r0=0.05, child="forearm", r1=0.035),
            sdf.ellipsoid("clavicle", S + np.array([0.005, 0.0, 0.01]), np.array([0.055, 0.05, 0.05]) * g,
                          axis=(self.clav_root, S), child="upper_arm", r1=0.03),
            sdf.ellipsoid("upper_arm", E - self.u_dir * 0.004 - f * 0.012, (0.020, 0.024, 0.020),
                          axis=(S, E), parent="clavicle", r0=0.05, child="forearm", r1=0.035),
            sdf.cone("forearm", E, M, 0.041 * g, 0.034 * g, z_ref=hz, sx=1.08, sz=0.92,
                     axis=(E, W), parent="upper_arm", r0=0.035, child="hand", r1=0.032, twist=True),
            sdf.cone("forearm", M, W - f * 0.006, 0.034 * g, 0.0265 * g, z_ref=hz, sx=1.12, sz=0.72,
                     axis=(E, W), parent="upper_arm", r0=0.035, child="hand", r1=0.032, twist=True),
            # brachioradialis: the muscle bulge on top of the forearm near the elbow
            sdf.ellipsoid("forearm", E + (W - E) * 0.22 + hz * 0.012 + self.hd((-1, 0, 0)) * 0.01,
                          np.array([0.030, 0.075, 0.026]) * g, y_axis=W - E, z_ref=hz,
                          axis=(E, W), parent="upper_arm", r0=0.035, child="hand", r1=0.032, twist=True),
        ]
        hp = self.hp
        # measured from the wrist joint, so the hand blends into the forearm exactly where the
        # forearm blends into the hand (a mismatch creases the skin when the wrist bends)
        wrist_axis = (hp((0, 0, 0)), hp((0, 0.03, 0)))
        palm = [
            sdf.cone("hand", hp((0.0015, -0.018, -0.001)), hp((0.0015, 0.014, -0.001)), 0.0285 * g, 0.0285 * g,
                     z_ref=hz, sx=1.0, sz=0.66, parent="forearm_twist", r0=0.03, axis=wrist_axis),
            sdf.box("hand", hp((0.0035, 0.056, -0.0015)), np.array([0.0335, 0.037, 0.0125]) * fg,
                    round_=0.0105 * fg, y_axis=self.hd((0, 1, 0)), z_ref=hz,
                    parent="forearm_twist", r0=0.03, axis=wrist_axis),
            sdf.ellipsoid("hand", hp((-0.0225, 0.036, -0.0115)), np.array([0.0165, 0.027, 0.0135]) * fg,
                          y_axis=self.hd((-0.45, 1, 0)), z_ref=hz, parent="forearm_twist", r0=0.03,
                          axis=wrist_axis, thenar=True),
            sdf.ellipsoid("hand", hp((0.0255, 0.042, -0.0075)), np.array([0.0125, 0.032, 0.0115]) * fg,
                          y_axis=self.hd((0.1, 1, 0)), z_ref=hz, parent="forearm_twist", r0=0.03, axis=wrist_axis),
            sdf.ellipsoid("hand", hp((0.0035, 0.082, -0.0085)), np.array([0.037, 0.0125, 0.0105]) * fg,
                          y_axis=self.hd((0, 1, 0)), z_ref=hz, parent="forearm_twist", r0=0.03, axis=wrist_axis),
        ]
        # metacarpals with knuckle heads
        for name in FINGERS:
            joints, radii, d, _z = self.chains[name]
            base = hp((FINGER_DATA[name][0][0] * 0.55, 0.016, 0.0))
            palm.append(sdf.cone("hand", base, joints[0] - d * 0.002 + hz * 0.0012, 0.0080 * fg, radii[0] * 0.97,
                                 z_ref=hz, sx=1.05, sz=0.85, parent="forearm_twist", r0=0.03, axis=wrist_axis))
        fingers = {}
        for name in ("thumb",) + FINGERS:
            joints, radii, d, zref = self.chains[name]
            prims = []
            sz = 0.92 if name == "thumb" else 0.86
            for k in range(3):
                bone = f"{name}.{k + 1:02d}"
                parent = "hand" if k == 0 else f"{name}.{k:02d}"
                child = f"{name}.{k + 2:02d}" if k < 2 else None
                r_start = radii[k] * (1.05 if name == "thumb" and k == 0 else 1.0)
                prims.append(sdf.cone(bone, joints[k], joints[k + 1], r_start, radii[k + 1], z_ref=zref,
                                      sx=1.0, sz=sz, parent=parent,
                                      r0=(0.016 if name == "thumb" else 0.012) if k == 0 else 0.007,
                                      child=child, r1=0.007))
                if k == 1:
                    # knuckle: a slight bulge at the middle joint
                    prims.append(sdf.ellipsoid(bone, joints[k] + _n(zref) * 0.0007,
                                               np.array([radii[k] * 0.99, radii[k] * 1.3, radii[k] * sz * 0.97]),
                                               y_axis=joints[k + 1] - joints[k], z_ref=zref,
                                               axis=(joints[k], joints[k + 1]), parent=parent, r0=0.007,
                                               child=child, r1=0.007))
            # finger pad on the palm side of the fingertip
            dist = prims[-1]
            pad_c = joints[2] + (joints[3] - joints[2]) * 0.55 - dist.rot[:, 2] * radii[3] * 0.25
            prims.append(sdf.ellipsoid(dist.bone, pad_c, np.array([radii[3] * 0.98, (radii[3] + 0.006),
                                                                   radii[3] * 0.8]),
                                       y_axis=joints[3] - joints[2], z_ref=zref, axis=(joints[2], joints[3]),
                                       parent=f"{name}.02", r0=0.007))
            # the nail: the fingertip's skin raised half a millimetre over a rounded patch
            length = np.linalg.norm(joints[3] - joints[2])
            frame = dist.rot
            r = radii[3]
            centre = joints[2] + frame[:, 1] * length * (0.62 if name != "thumb" else 0.58) \
                + frame[:, 2] * r * sz
            region = sdf.box(dist.bone, centre, (r * 0.74, length * 0.40, r * sz * 0.55), round_=r * 0.45,
                             y_axis=frame[:, 1], z_ref=frame[:, 2])
            prims.append(sdf.Prim("nail", dist.bone, base=dist, region=region, lift=0.0009, label="nail",
                                  axis=(joints[2], joints[3]), parent=f"{name}.02", r0=0.007,
                                  c=centre, radii=np.array([r * 1.3, length * 0.5, r * 1.3])))
            fingers[name] = prims
        return {"arm": arm, "palm": palm, "fingers": fingers}

