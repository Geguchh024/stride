# SPDX-License-Identifier: GPL-3.0-or-later
"""Meshing an arm from its skin shapes, with skin weights and shading masks (numpy, no bpy).

The result is plain arrays (cached as .npz) so adding hands in Blender is
instant after the first build.
"""

import os

import numpy as np

from . import anatomy, sdf

CACHE_VERSION = 12
K_ARM, K_PALM, K_JOIN = 0.022, 0.010, 0.016
K_FINGER, K_FINGER_PALM, K_THUMB_PALM = 0.002, 0.0065, 0.013
CHUNK = 400_000


class Field:
    """The arm's signed distance: groups blended inside, fingers blended only with the palm."""

    def __init__(self, groups):
        self.arm = groups["arm"]
        self.palm = groups["palm"]
        self.fingers = groups["fingers"]

    @staticmethod
    def _group(prims, p, k, hard=()):
        out = np.full(len(p), 1.0)
        for pr in prims:
            lo, hi = pr.aabb()
            lo, hi = lo - k - 0.002, hi + k + 0.002
            m = np.all((p >= lo) & (p <= hi), axis=1)
            if not m.any():
                continue
            d = pr.distance(p[m])
            if pr.kind == "nail":
                out[m] = np.minimum(out[m], d)
            else:
                out[m] = sdf.smin(out[m], d, k)
        return out

    def __call__(self, p):
        p = np.asarray(p, float).reshape(-1, 3)
        out = np.empty(len(p))
        for i in range(0, len(p), CHUNK):
            out[i:i + CHUNK] = self._eval(p[i:i + CHUNK])
        return out

    def _eval(self, p):
        d_arm = self._group(self.arm, p, K_ARM)
        d_palm = self._group(self.palm, p, K_PALM)
        d = sdf.smin(d_arm, d_palm, K_JOIN)
        for name, prims in self.fingers.items():
            skin = [pr for pr in prims if pr.kind != "nail"]
            d_f = self._group(skin, p, K_FINGER)
            for pr in prims:
                if pr.kind == "nail":
                    lo, hi = pr.aabb()
                    m = np.all((p >= lo) & (p <= hi), axis=1)
                    if m.any():
                        d_f[m] = np.minimum(d_f[m], pr.distance(p[m]))
            k = K_THUMB_PALM if name == "thumb" else K_FINGER_PALM
            d = np.minimum(d, sdf.smin(d_palm, d_f, k))
        return d

    def prims(self):
        out = list(self.arm) + list(self.palm)
        for prims in self.fingers.values():
            out += prims
        return out


def _smooth01(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def _segment_distance(p, a, b):
    ab = b - a
    t = np.clip(((p - a) @ ab) / max(ab @ ab, 1e-12), 0.0, 1.0)
    return np.linalg.norm(p - (a + np.outer(t, ab)), axis=1)


def bone_segments(arm):
    """Line segments standing for each bone when measuring how close the skin is to it.

    The hand is the fan of metacarpals (wrist to each knuckle and to the thumb's base),
    so the palm sticks to the hand instead of being pulled along by a nearby finger.
    """
    segs = {}
    for name, head, tail, _z, _parent, _conn in arm.bones():
        if name in ("forearm_twist", "hand"):
            continue
        segs[name] = [(np.asarray(head), np.asarray(tail))]
    w = arm.wrist
    segs["hand"] = [(w, arm.chains[f][0][0]) for f in anatomy.FINGERS] + [(w, arm.chains["thumb"][0][0])]
    return segs


SKIN_POWER = 5.0
SIBLING = 1.3      # neighbouring fingers look this much further away


def skin_weights(arm, field, verts):
    """Bone weights per vertex, from how close the skin is to each bone.

    Distances vary smoothly over the skin, so weights never jump between
    neighbouring vertices (no cracks at the joints). Each vertex only listens to
    its own bone (the one under its nearest skin shape) and that bone's parent
    and children, which keeps fingers independent of each other. The forearm's
    weight is then shared with the twist bone along its length.
    Returns ({bone: weights}, primary shape index, shapes).
    """
    prims = list(field.prims())
    d = np.column_stack([pr.distance(verts) for pr in prims])
    primary = np.argmin(d, axis=1)

    bones = arm.bones()
    parent = {b[0]: b[4] for b in bones}
    parent["hand"] = "forearm"           # the twist bone shares the forearm's place
    segs = bone_segments(arm)
    names = list(segs)
    col = {n: i for i, n in enumerate(names)}
    # which bones a vertex may follow, given its own bone, and how far away each one is
    # made to look: family along the chain counts fully, sibling fingers only at the web
    scale = np.full((len(names), len(names)), np.inf)
    for n in names:
        i = col[n]
        scale[i, i] = 1.0
        p = parent.get(n)
        g = parent.get(p) if p else None
        for other in (p, g):
            if other in col:
                scale[i, col[other]] = scale[col[other], i] = 1.0
        for m in names:
            if m != n and p is not None and parent.get(m) == p:
                scale[i, col[m]] = min(scale[i, col[m]], SIBLING)
    dist = np.column_stack([np.min([_segment_distance(verts, a, b) for a, b in segs[n]], axis=0)
                            for n in names])
    own = np.array([col["forearm" if pr.bone == "forearm_twist" else pr.bone] for pr in prims])[primary]
    w = (np.maximum(dist, 1e-4) * scale[own]) ** -SKIN_POWER
    w /= w.sum(axis=1, keepdims=True)
    weights = {n: w[:, i] for i, n in enumerate(names) if w[:, i].max() > 1e-4}

    # share the forearm with the twist bone: none at the elbow, all of it at the wrist
    fore = weights.get("forearm")
    if fore is not None:
        e, wr = arm.elbow, arm.wrist
        t = np.clip(((verts - e) @ (wr - e)) / ((wr - e) @ (wr - e)), 0.0, 1.0)
        share = _smooth01(0.1, 0.95, t)
        weights["forearm_twist"] = fore * share
        weights["forearm"] = fore * (1.0 - share)
    return weights, primary, prims


def field_prims(arm):
    groups = arm.skin()
    return Field(groups).prims()


def masks(arm, verts, normals, weights):
    """Shading masks: nail, fingertip and knuckle flush, palm side."""
    # nails: a soft-edged patch on the back of each fingertip (blended in the skin shader)
    nail = np.zeros(len(verts))
    for pr in field_prims(arm):
        if pr.kind == "nail":
            d = pr.region.distance(verts)
            facing = normals @ pr.region.rot[:, 2]
            nail = np.maximum(nail, _smooth01(0.0007, -0.0005, d) * _smooth01(0.15, 0.45, facing))
    knuckle = np.zeros(len(verts))
    flush = np.zeros(len(verts))
    palm = np.zeros(len(verts))
    hz = arm.hand_z
    # how much each vertex belongs to the hand (smooth across the wrist, no seam)
    on_hand = sum(w for b, w in weights.items() if b == "hand" or "." in b)
    on_hand = np.clip(on_hand, 0.0, 1.0)
    for name in ("thumb",) + anatomy.FINGERS:
        joints, radii, _d, _z = arm.chains[name]
        tip = np.linalg.norm(verts - joints[3], axis=1)
        flush = np.maximum(flush, _smooth01(0.02, 0.004, tip))
        for k in range(3):
            dj = np.linalg.norm(verts - joints[k], axis=1)
            near = _smooth01(radii[k] * 1.8, radii[k] * 0.9, dj)
            flush = np.maximum(flush, 0.6 * near)
            if name != "thumb" or k > 0:
                knuckle = np.maximum(knuckle, _smooth01(radii[k] * 1.5, radii[k] * 0.7, dj))
    side = normals @ -hz
    palm = _smooth01(-0.15, 0.45, side) * on_hand
    flush = np.clip(flush + 0.35 * palm, 0, 1) * on_hand
    knuckle = knuckle * _smooth01(-0.1, 0.4, normals @ hz) * on_hand
    return {"nail": nail, "flush": flush, "palm": palm, "knuckle": knuckle}


def build(build_id="AVERAGE", h=0.0021):
    arm = anatomy.Arm(anatomy.BUILDS[build_id])
    field = Field(arm.skin())
    pr = field.prims()
    lo = np.min([p.aabb()[0] for p in pr], axis=0) - 0.01
    hi = np.max([p.aabb()[1] for p in pr], axis=0) + 0.01
    grid = sdf.Grid(lo, hi, h)
    axes = [grid.lo[d] + grid.h * np.arange(grid.n[d]) for d in range(3)]
    pts = np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3)
    values = field(pts).reshape(tuple(grid.n))
    verts, quads = sdf.surface_nets(values, grid)
    verts = sdf.relax(verts, quads, field, iters=3, smooth=0.45)
    normals = sdf.gradient(verts, field)
    normals /= np.maximum(np.linalg.norm(normals, axis=1), 1e-9)[:, None]
    weights, _primary, _prims = skin_weights(arm, field, verts)
    m = masks(arm, verts, normals, weights)
    return {"verts": verts.astype(np.float32), "quads": quads.astype(np.int32),
            "bones": arm.bones(), "weights": {k: v.astype(np.float32) for k, v in weights.items()},
            "masks": {k: v.astype(np.float32) for k, v in m.items()}}


def save(data, path):
    arrays = {"verts": data["verts"], "quads": data["quads"], "version": np.array([CACHE_VERSION])}
    # half floats keep the shipped files small; weights are renormalised on load
    for k, v in data["weights"].items():
        arrays["w_" + k] = np.asarray(v, np.float16)
    for k, v in data["masks"].items():
        arrays["m_" + k] = np.asarray(v, np.float16)
    np.savez_compressed(path, **arrays)


def load(path):
    if not os.path.exists(path):
        return None
    z = np.load(path)
    if "version" not in z or int(z["version"][0]) != CACHE_VERSION:
        return None
    weights = {k[2:]: z[k].astype(np.float32) for k in z.files if k.startswith("w_")}
    total = np.maximum(sum(weights.values()), 1e-6)
    return {"verts": z["verts"], "quads": z["quads"],
            "weights": {k: v / total for k, v in weights.items()},
            "masks": {k[2:]: z[k].astype(np.float32) for k in z.files if k.startswith("m_")}}


def cached(build_id, folder):
    """The arm mesh for a build, from the cache folder or freshly built (and then cached)."""
    path = os.path.join(folder, f"arm_{build_id.lower()}.npz")
    data = load(path)
    if data is None:
        data = build(build_id)
        os.makedirs(folder, exist_ok=True)
        save(data, path)
        data = load(path)
    return data


def mirror(data):
    """The left arm: mirrored across X, faces flipped, '.R' bones renamed."""
    v = data["verts"].copy()
    v[:, 0] *= -1
    return {"verts": v, "quads": data["quads"][:, ::-1].copy(), "weights": data["weights"],
            "masks": data["masks"]}





# -- sleeves ---------------------------------------------------------------------------

# kind: cuff distance before the wrist (m, or ("upper", t) for short sleeves), ease, thickness,
# fold depth, cuff bunching
SLEEVE_CUT = {
    "canvas": (0.034, 0.010, 0.003, 0.0032, 0.004),
    "jersey": (0.022, 0.011, 0.003, 0.0040, 0.008),
    "twill": (0.030, 0.008, 0.003, 0.0028, 0.003),
    "leather": (0.036, 0.008, 0.002, 0.0022, 0.002),
    "plaid": (0.028, 0.006, 0.0025, 0.0030, 0.003),
    "knit": (0.026, 0.012, 0.005, 0.0035, 0.007),
    "wool": (0.048, 0.008, 0.003, 0.0016, 0.0),
    "tee": (("upper", 0.45), 0.012, 0.0025, 0.0030, 0.0),
}


class _ArmOnly:
    def __init__(self, prims):
        self._p = prims

    def prims(self):
        return self._p


def _solid(arm_field, p, ease, cut_point, cut_dir, back_point=None):
    """The arm grown by ``ease``, cut off at the cuff plane (and optionally behind)."""
    out = np.maximum(arm_field(p) - ease, (p - cut_point) @ cut_dir)
    if back_point is not None:
        out = np.maximum(out, -((p - back_point) @ cut_dir))
    return out


def _drop_caps(verts, quads, planes, h):
    """Open the sleeve: remove the flat faces closing it at the cuff planes."""
    c = verts[quads].mean(axis=1)
    n = np.cross(verts[quads[:, 2]] - verts[quads[:, 0]], verts[quads[:, 3]] - verts[quads[:, 1]])
    n /= np.maximum(np.linalg.norm(n, axis=1), 1e-12)[:, None]
    keep = np.ones(len(quads), bool)
    for point, direction in planes:
        on = np.abs((c - point) @ direction) < h * 0.9
        keep &= ~(on & (n @ direction > 0.5))
    quads = quads[keep]
    used = np.unique(quads)
    remap = -np.ones(len(verts), np.int64)
    remap[used] = np.arange(len(used))
    return verts[used], remap[quads], used


def build_sleeve(build_id, kind, h=0.0024):
    """A loose fabric sleeve over the arm, open at the cuff, with folds.

    Meshed as a single surface; the add-on gives it thickness with a
    Solidify modifier, so the cloth never has holes where it is thinner
    than the mesh.
    """
    arm = anatomy.Arm(anatomy.BUILDS[build_id])
    prims = arm.skin()["arm"]
    arm_field = lambda p: Field._group(prims, p, K_ARM)  # noqa: E731
    cut_spec, ease0, _th, fold, bunch = SLEEVE_CUT[kind]
    f = arm.f_dir
    if isinstance(cut_spec, tuple):
        t = cut_spec[1]
        cut_dir = arm.u_dir
        cut_point = arm.shoulder + (arm.elbow - arm.shoulder) * t
    else:
        cut_dir = f
        cut_point = arm.wrist - f * cut_spec
    shirt_cut = arm.wrist - f * 0.024
    shirt_back = arm.wrist - f * 0.11

    def ease(p):
        # folds: broad soft wrinkles, and rings of fabric bunched up towards the cuff
        n = sdf.noise3(p * 26.0, 3) * 0.7 + sdf.noise3(p * 52.0, 5) * 0.3
        along = -((p - cut_point) @ cut_dir)
        near_cuff = np.clip(1.0 - along / 0.11, 0.0, 1.0)
        rings = np.sin(along * (np.pi * 2 / 0.038) + 2.5 * sdf.noise3(p * 18.0, 9))
        rings = np.maximum(rings, -0.3)
        e = ease0 + fold * (0.7 * n + 0.5 * rings * near_cuff) + bunch * near_cuff ** 2 * (0.6 + 0.4 * n)
        if kind in ("jersey", "knit"):
            # ribbed cuff hugs the wrist
            e = e - (ease0 * 0.75) * np.clip(1.0 - along / 0.035, 0, 1)
        return np.maximum(e, 0.0015)

    def shirt_field(p):
        return _solid(arm_field, p, 0.0035 + 0.0008 * sdf.noise3(p * 90, 7), shirt_cut, f, back_point=shirt_back)

    def field(p):
        p = np.asarray(p, float).reshape(-1, 3)
        d = _solid(arm_field, p, ease(p), cut_point, cut_dir)
        if kind == "wool":
            # the shirt cuff showing below the jacket sleeve
            d = np.minimum(d, shirt_field(p))
        return d

    lo = np.min([p.aabb()[0] for p in prims], axis=0) - 0.03
    hi = np.max([p.aabb()[1] for p in prims], axis=0) + 0.03
    grid = sdf.Grid(lo, hi, h)
    axes = [grid.lo[d] + grid.h * np.arange(grid.n[d]) for d in range(3)]
    pts = np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3)
    values = np.empty(len(pts))
    for i in range(0, len(pts), CHUNK):
        values[i:i + CHUNK] = field(pts[i:i + CHUNK])
    verts, quads = sdf.surface_nets(values.reshape(tuple(grid.n)), grid)
    verts = sdf.relax(verts, quads, field, iters=2, smooth=0.4)
    planes = [(cut_point, cut_dir)] + ([(shirt_cut, f)] if kind == "wool" else [])
    verts, quads, _used = _drop_caps(verts, quads, planes, h)
    weights, _primary, _prims = skin_weights(arm, _ArmOnly(prims), verts)
    along = -((verts - cut_point) @ cut_dir)
    hem = np.clip(1.0 - along / 0.012, 0.0, 1.0)
    shirt = np.zeros(len(verts))
    if kind == "wool":
        d_jacket = _solid(arm_field, verts, ease(verts), cut_point, cut_dir)
        shirt = (np.abs(shirt_field(verts)) < np.abs(d_jacket)).astype(float)
        hem = hem * (1 - shirt)
    return {"verts": verts.astype(np.float32), "quads": quads.astype(np.int32),
            "weights": {k: v.astype(np.float32) for k, v in weights.items()},
            "masks": {"hem": hem.astype(np.float32), "shirt": shirt.astype(np.float32)}}


def cached_sleeve(build_id, kind, folder):
    path = os.path.join(folder, f"sleeve_{build_id.lower()}_{kind}.npz")
    data = load(path)
    if data is None:
        data = build_sleeve(build_id, kind)
        os.makedirs(folder, exist_ok=True)
        save(data, path)
        data = load(path)
    return data
